public class Address{
    private String fline;
    private String sline;
    private String tline;
    
    public Address(){
        
    }
    
    public Address(String fline, String sline, String tline){
        this.fline = fline;
        this.sline = sline;
        this.tline = tline;
    }
    
    public void setFLine(String fline){
        this.fline = fline;
    }
    
    public String getFLine(){
        return fline;
    }
    
    public void setSLine(String sline){
        this.sline = sline;
    }
    
    public String getSLine(){
        return sline;
    }
    
    public void setTLine(String tline){
        this.tline = tline;
    }
    
    public String getTLine(){
        return tline;
    }
    
    @Override
    public String toString(){
        return fline + "\n" + sline + "\n" + tline;
    }
}