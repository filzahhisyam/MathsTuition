// created by team in KL
public class Student extends TuitionCentreKL {
    // data/attributes
    Name name; //encapsulation: objects from another class
    String kp;
    Address address;
    String schoolname;
    
    public Student(Name name, String kp, Address address, String schoolname){
        this.name = name;
        this.kp = kp;
        this.address = address;
        this.schoolname = schoolname;
    }
    
    public void setkp(String kp){
        this.kp = kp;
    }
    
    public void setSchoolName(String schoolname){
        this.schoolname = schoolname;
    }

    float marks[] = new float[5];
    
    public Student(){
        System.out.println("Student object created");
    }
    
    // methods or operations
    float calcAvg() {
        float total = 0;
        float avg = 0;
        for(int i = 0; i < marks.length; i++){
            total+=marks[i];
        }
         avg = total / 5;
        return avg;
    }
    
    float calcMin() {
        float max = 99999999;
        float min = 0;
        for(int i = 0; i < marks.length; i++)
        if (marks[i] < max){
           min = marks[i];
        }
        return min;
    }

//setter method
//avoid direct access to attributes

    void setFullName(Name thename){
        name = thename;
        
    }
//marks array so kena tulis macam ni for setter method
    void setMark(float mark, int i) {
        marks[i] = mark;        
    }
    
    public String toString(){
        return name + kp + address + schoolname;
    }
    
}