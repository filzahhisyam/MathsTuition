public class TuitionCentreJB{
    
}