public class TuitionCentreKL {
    protected Teacher teacher[];
    protected Student student[];
    
    
    
    
}
