/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
// application team in UTP
public class Main
{
    // application code
	public static void main(String[] args) {
	    
        Student mike = new Student();
        Name name = new Name();
        name.setFName("Michael ");
        name.setMName("B ");
        name.setLName("Jordan");
        mike.setFullName(name); // object tu dah ada all the first middle and last name
        System.out.println(name.toString());
        System.out.println("\n");
        
        Student adila = new Student();
        name = new Name();
        name.setFName("Adila"); // access directly = attributes constantly changing
        name.setMName(" binti");
        name.setLName(" Izzat");
        adila.setFullName(name);
        System.out.println(name.toString());
        System.out.println("\n");
        
        StudentBatch sb2023 = new StudentBatch();
        sb2023.add(mike);
        sb2023.add(adila,0);
        
        Student imran = new Student();
        name = new Name("Syed", " Imran", " Shah ");
        Address address = new Address("11A Jalan Dagang", "6/3 Taman Dagang", "68000 Ampang, Selangor"); 
        
        //kat dalam studentBatch bc ada sb
        imran = new Student(name, "030320100782 ", address, " KL branch");
        System.out.println(imran.toString());
        System.out.println("------------------------------------");
        
        boolean isIn = sb2023.findName("Adlin"); //adlin ada tak kat returns true or false
        System.out.println(isIn + ", not in the name list.");
        
        /*Address address = new Address("11A Jalan Dagang", "6/3 Taman Dagang", "68000 Ampang, Selangor"); 
        //kat dalam studentBatch bc ada sb
        System.out.println("Student Address: " + address.toString());*/
        
        Address schooladdress = new Address("Jalan Baling", "Km 1", "33100 Pengkalan Hulu, Perak");
        System.out.println("School Address: " + schooladdress.toString());

        Teacher cikguminah = new Teacher();
 
        //set marks for mike
        for (int i=0; i<5; i++) 
            mike.setMark(100, i);
        
        // calculate and print the avg
        float avg = 0;
        avg = mike.calcAvg();
        System.out.println("Avg = " + avg);
        
        
        // calculate the min marks for mike
        System.out.println("Min = " + mike.calcMin());        
	}
}
