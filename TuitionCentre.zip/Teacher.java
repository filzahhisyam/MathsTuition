// createed by team in Bangalore
class Teacher extends TuitionCentreKL {
    // data
    String name;
    String ic;
    String address;
    int numyearexp;
    String qualification;
    String datejoined;
    
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getIc() {
        return ic;
    }
    public void setIc(String ic) {
        this.ic = ic;
    }
    public String getAddress() {
        return address;
    }
    public void setAddress(String address) {
        this.address = address;
    }
    public int getNumyearexp() {
        return numyearexp;
    }
    public void setNumyearexp(int numyearexp) {
        this.numyearexp = numyearexp;
    }
    public String getQualification() {
        return qualification;
    }
    public void setQualification(String qualification) {
        this.qualification = qualification;
    }
    public String getDateJoined(){
        return datejoined;
    }
    public void setDateJoined(){
        this.datejoined = datejoined;
    }
    

    
}