public class Name{
    private String fname; // global to the class
    private String lname;
    private String mname;
    
    public Name(){
        
    }
    
    public Name(String fname, String mname, String lname){
        this.fname = fname; //or this.fname = fname//this.mname = mname
        this.mname = mname;
        this.lname = lname;
        
    }
    
    public void setFName(String fname) { // local variable
    // this refers to the class attribute, bukan local tau
        this.fname = fname;
}

    public String getFname(){
        return fname;
    }

    public void setMName(String mname) { // local variable
    // this refers to the class attribute, bukan local tau
        this.mname = mname;
}

    public String getMName(){
        return mname;
    }

    public void setLName(String lname) { // local variable
    // this refers to the class attribute, bukan local tau
        this.lname = lname;
}

    public String getLName(){
        return lname;
    }
    
    @Override
    public String toString(){
        return fname + mname + lname;
    }
    


    }    
