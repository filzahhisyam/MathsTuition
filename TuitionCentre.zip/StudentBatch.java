public class StudentBatch {
    //data section 
    //what is a student batch?
    // a student batch is a list of students reg in a batch
    // list of students = array of students
    
    Student students[] = new Student[10];
    int currsz = 0;
    
    //datatype is student
    //operation section
    
    void add(Student s, int i){
        students[i] = s;
    }
    
    //method overloading = single name multiple usage
    void add(Student s){
        students[currsz++] = s;
    }
    
   boolean findName(String name){
        //loop through student array
        //check whether the name is the same as in the student
        
        for(int i=0; i<currsz; i++){ //look through the currsz only
         if(students[i].name.getFname() == name){
            return true;
        }
        }
        return false;
        }
}